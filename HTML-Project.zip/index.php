<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php echo '<p>Hello World! Here are all of my Links [Namit Joshi, Period 2]</p>'; ?> 
    <ul>
      <li><a href="index.html">index.html</a></li></br>
      <!-- Please make sure to change all the #'s to the proper link names-->
      <li><a href="Joshi_AboutMe.html">AboutMe.html</a></li></br>
      <li><a href="Joshi_Projects.html">Projects.html</a></li></br>
      <li><a href="Joshi_Resume.html">Resume.html</a></li></br>
      <li><a href="Joshi_ContactMe.html">ContactMe.html</a></li></br>
    <ul>
  </body>
</html>